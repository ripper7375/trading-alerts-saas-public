# WorldGoldMarket isolated arithmetic mutation verification

The unchanged repository `__tests__/lib/world-gold/pricing.test.ts` passes against the real pricing source and fails against the isolated arithmetic mutant. Only scratch files were written.

Reproduce from `D:\SaaS Project\trading-alerts-saas-public`:

```powershell
node 'C:\Users\WiN\Documents\Codex\2026-10-15\i\work\worldgold-mutation-final\native-run.cjs'
```

The harness exits **0** when the baseline passes, the intended mutant fails its numerical assertions, the mutant is demonstrably loaded, and all protected live-source hashes remain unchanged. It spawns hidden Node children with a finite **20,000 ms** timeout each.

| Execution | Child exit | Passed | Failed tests/assertions | Assertions executed |
| --- | --- | --- | --- | --- |
| Baseline | 0 | 27 | 0 | 65 |
| Mutant | 1 | 15 | 12 | 52 |

The mutant changes the single real production expression `(xauUsd * localPerUsd) / TROY_OUNCE_GRAMS` to `(xauUsd * localPerUsd) * TROY_OUNCE_GRAMS`. Its relative catalog import is redirected to the unchanged live catalog because the mutant resides in scratch. The real test source, fixtures, catalog and schedule are read directly from the repository and are not copied or edited.

All ten independently worked market fixture cases fail `toBeCloseTo`; the GBP quote-direction and exact Thai-purity cases also fail `toBeCloseTo`. For example, GBP's expected first value is **2488.278144**, while the mutant returns **2407225.641203946**. These are numerical assertion failures, not configuration, import or compilation failures.

The native runner uses installed TypeScript to transpile the unchanged real test source and its real imports, and installed Jest `expect` matchers to evaluate every actual test callback. It supplies the synchronous `describe`, `test` and `test.each` registration used by this particular test file. Explicit module resolution maps only the pricing alias to the mutant for the mutation run; dependency load paths and SHA256 values are recorded. It does not claim to be the Jest CLI.

The previous alias-only Jest attempt was unsuitable proof because it passed despite the arithmetic mutant. Next/SWC can rewrite tsconfig aliases before Jest's module mapper. The new native loader preserves and explicitly resolves imports, records the loaded mutant path, and enforces the expected assertion failures. A separate scratch Jest setup also encountered sandbox `EPERM` on ancestor realpath during package lookup; scratch `package.json` bounds that walk, but the initial unscoped repository crawl was bounded separately and is not used as proof.

That separate Jest attempt has ended: both children reached their 90-second limit and were terminated (`ETIMEDOUT`, `SIGTERM`; overall harness exit 1). Its `evidence.json` and unprefixed logs are retained as failed-attempt diagnostics only. The completed proof is the **native-prefixed evidence** listed below; no verifier remains running.

Live pricing SHA256 before and after is **3867351b69f3251aef5f288b6dcaffb9f7bccdf0aa3950a5e338bd613f26ed70**. The real test, fixtures, catalog and schedule hashes also match before and after in `native-evidence.json`.

Durable evidence in this directory:

- `native-evidence.json`: commands, exits, mutation, before/after hashes, resolved pricing paths, all twelve assertion failures.
- `native-baseline.json`, `native-mutant.json`: full test records, matcher output and loaded dependency paths/hashes.
- `native-baseline.stdout.log`, `native-mutant.stdout.log`: durable child output.
- `native-baseline.stderr.log`, `native-mutant.stderr.log`: empty on the successful verification.
- `native-run.cjs`, `pricing.native-mutant.ts`: reproducible isolated runner and actual mutant source.

No live repository source, generated files, database, build or development server was changed by this verification.
