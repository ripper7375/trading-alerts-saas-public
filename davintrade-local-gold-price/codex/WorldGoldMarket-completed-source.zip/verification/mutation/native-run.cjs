const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const { spawnSync } = require('node:child_process');
const util = require('node:util');
const root = 'D:/SaaS Project/trading-alerts-saas-public';
const scratch = __dirname;
const sourcePath = path.join(root, 'lib/world-gold/pricing.ts');
const testPath = path.join(root, '__tests__/lib/world-gold/pricing.test.ts');
const mutantPath = path.join(scratch, 'pricing.native-mutant.ts');
const digest = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');

if (process.argv[2] === '--worker') {
  const mode = process.argv[3];
  const ts = require(path.join(root, 'node_modules/typescript'));
  const jestRequire = createRequire(require.resolve(path.join(root, 'node_modules/jest')));
  const cliRequire = createRequire(jestRequire.resolve('jest-cli'));
  const coreRequire = createRequire(cliRequire.resolve('@jest/core'));
  const runtimeRequire = createRequire(coreRequire.resolve('jest-runtime'));
  global.expect = runtimeRequire('@jest/expect').jestExpect;
  const records = [];
  const suites = [];
  const loaded = [];
  const cache = new Map();
  global.describe = (name, fn) => { suites.push(name); try { fn(); } finally { suites.pop(); } };
  const execute = (name, fn, args = []) => {
    expect.setState({ assertionCalls: 0, numPassingAsserts: 0 });
    try {
      fn(...args);
      records.push({ name: [...suites, name].join(' > '), status: 'passed',
        assertions: expect.getState().assertionCalls });
    } catch (error) {
      records.push({ name: [...suites, name].join(' > '), status: 'failed',
        assertions: expect.getState().assertionCalls, failure: error.message,
        matcher: error.matcherResult?.name ??
          (error.message.includes('.toBeCloseTo(') ? 'toBeCloseTo' : null) });
    }
  };
  global.test = (name, fn) => execute(name, fn);
  global.test.each = (rows) => (name, fn) => {
    for (const row of rows) {
      const args = Array.isArray(row) ? row : [row];
      let index = 0;
      const title = name.replace(/%[sdifjop]/g, (token) => util.format(token, args[index++]));
      execute(title, fn, args);
    }
  };
  const load = (file) => {
    file = path.normalize(file);
    if (cache.has(file)) return cache.get(file).exports;
    const module = { exports: {} };
    cache.set(file, module);
    const source = fs.readFileSync(file, 'utf8');
    loaded.push({ file, sha256: digest(file) });
    const { outputText } = ts.transpileModule(source, { fileName: file, compilerOptions: {
      module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022,
      esModuleInterop: true, isolatedModules: true,
    }});
    const localRequire = (id) => {
      if (id === '@/lib/world-gold/pricing') return load(mode === 'mutant' ? mutantPath : sourcePath);
      let resolved;
      if (id.startsWith('@/')) resolved = path.join(root, id.slice(2));
      else if (id.startsWith('.')) resolved = path.resolve(path.dirname(file), id);
      else return createRequire(file)(id);
      if (!path.extname(resolved)) resolved += '.ts';
      return load(resolved);
    };
    new Function('require', 'module', 'exports', '__filename', '__dirname', outputText)(
      localRequire, module, module.exports, file, path.dirname(file));
    return module.exports;
  };
  load(testPath);
  const failed = records.filter((record) => record.status === 'failed');
  const result = { mode, total: records.length, passed: records.length - failed.length,
    failed: failed.length, failingAssertionCount: failed.length,
    assertionsExecuted: records.reduce((sum, record) => sum + record.assertions, 0),
    testSource: testPath, testSourceSha256: digest(testPath), loaded, records };
  console.log(JSON.stringify(result, null, 2));
  process.exitCode = failed.length ? 1 : 0;
} else {
  const protectedFiles = [sourcePath, testPath,
    path.join(root, '__tests__/lib/world-gold/fixtures.ts'),
    path.join(root, 'lib/world-gold/catalog.ts'),
    path.join(root, 'lib/world-gold/schedule.ts')];
  const before = Object.fromEntries(protectedFiles.map((file) => [file, digest(file)]));
  const source = fs.readFileSync(sourcePath, 'utf8');
  const from = '(xauUsd * localPerUsd) / TROY_OUNCE_GRAMS';
  const to = '(xauUsd * localPerUsd) * TROY_OUNCE_GRAMS';
  if (source.split(from).length !== 2) throw new Error('Expected one arithmetic mutation site');
  // Only production-source arithmetic is mutated; the import redirects back to
  // the real catalog because the mutant itself lives in isolated scratch.
  fs.writeFileSync(mutantPath, source.replace(from, to)
    .replace("from './catalog'", "from '@/lib/world-gold/catalog'"));
  const results = [];
  for (const mode of ['baseline', 'mutant']) {
    const args = [__filename, '--worker', mode];
    const child = spawnSync(process.execPath, args, {
      cwd: root, encoding: 'utf8', windowsHide: true, timeout: 20000,
      maxBuffer: 4 * 1024 * 1024, env: { ...process.env, CI: 'true', TZ: 'UTC' },
    });
    fs.writeFileSync(path.join(scratch, `native-${mode}.stdout.log`), child.stdout || '');
    fs.writeFileSync(path.join(scratch, `native-${mode}.stderr.log`), child.stderr || '');
    const report = child.stdout ? JSON.parse(child.stdout) : null;
    if (report) fs.writeFileSync(path.join(scratch, `native-${mode}.json`), JSON.stringify(report, null, 2) + '\n');
    results.push({ mode, command: [process.execPath, ...args], exit: child.status,
      signal: child.signal, error: child.error?.message ?? null, timeoutMs: 20000,
      total: report?.total, passed: report?.passed, failed: report?.failed,
      failingAssertionCount: report?.failingAssertionCount,
      assertionsExecuted: report?.assertionsExecuted,
      resolvedPricing: report?.loaded.filter((item) => item.file.includes('pricing')),
      failedTests: report?.records.filter((record) => record.status === 'failed'),
    });
  }
  const after = Object.fromEntries(protectedFiles.map((file) => [file, digest(file)]));
  const unchanged = protectedFiles.every((file) => before[file] === after[file]);
  const [baseline, mutant] = results;
  const success = unchanged && baseline.exit === 0 && baseline.total === 27 &&
    baseline.failed === 0 && mutant.exit === 1 && mutant.failed === 12 &&
    mutant.failedTests.every((test) => test.matcher === 'toBeCloseTo') &&
    mutant.resolvedPricing.some((item) => item.file === path.normalize(mutantPath));
  const report = { generatedAt: new Date().toISOString(), success, runner: 'Native Node, unchanged real TypeScript test source, installed Jest expect matchers',
    mutation: { from, to, file: mutantPath, sha256: digest(mutantPath) },
    before, after, liveSourcesUnchanged: unchanged, results };
  fs.writeFileSync(path.join(scratch, 'native-evidence.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ success, liveSourcesUnchanged: unchanged,
    results: results.map(({failedTests, resolvedPricing, ...summary}) => summary) }, null, 2));
  process.exitCode = success ? 0 : 1;
}
