---
type: Concept/Task
status: in_progress
updated_at: 2026-10-15
task_id: 2026-10-15-worldgoldmarket
owner: Codex
integrator: Codex root
reviewer: Codex independent subagent
shared_state_writer: handoff-only
approval: Davin requested a build plan and implementation of WorldGoldMarket using the supplied screenshots and ten-market HTML definitions.
order_mode: ad-hoc; phase/session unchanged
base_commit: e64f94ffb6175083524589b22cb9be699b26d00c
worktree: 'D:\SaaS Project\trading-alerts-saas-public'
branch: main
---

# Objective

Add public /worldgoldmarket with all ten local gold markets, formula-derived prices in local units, previous local close changes, schedule status, collapsible source/formula details, source timestamps and attribution. Move Docs, Blog and Academy into More and add WorldGold to primary navigation.

## Scope and ownership

- Root owns page/component, navigation, build plan, task/handoff, final integration and all shared check/dev resources.
- Backend subagent owns lib/world-gold/**, app/api/world-gold/**, app/api/cron/world-gold/\*\*, new world-gold tests, dedicated migration and additive Prisma market-data model/mirror.
- Locale subagent owns only worldGold.\* entries in all 19 dictionary files and any necessary identical-translation exceptions for these keys.
- Preserve initial unrelated changes: recent-works, next-env.d.ts, mobile-app deletions, supplied untracked folders and prior records. No existing intended target runtime file was dirty. No active-tasks.md exists.
- Exclude payments/auth/grants/CORS, seed-code, dependency updates, production data mutations and shared Claude state.
- No commit, push, migration application, deployment or production flags authorized.

## Checklist

- [x] Inspect live source, instructions and source definitions.
- [x] Write build plan and implement authorized scope.
- [ ] Verify formulas, schedules/DST, frozen-close integrity, providers, API and responsive browser UI.
- [ ] Review and fix findings.
- [ ] Write unique handoff and user deliverable report.

## Decisions and deviations

- Davin explicitly accepted reference close benchmarks: UK 17:00, TH 17:30, HK floor 16:30, JP day 15:45, IN 23:30, UAE 22:00, TR BIST 18:00, DE/CH 17:30, AU 17:00, local times. Mon-Fri except UAE daily/reduced Friday; holidays unverified.
- CurrencyBeacon is used for fiat FX. PostgreSQL market_data_v6 supplies XAUUSD; official CurrencyBeacon currencies do not establish XAU support.
- Separate market FX contract is needed because existing subscription FX excludes AUD/CHF/HKD. Do not change shared payment rates/cache contract.
- Preserve the existing eight-hour CurrencyBeacon raw-input retention limit. Save immutable calculated close prices and provenance for comparisons; any raw FX archive must expire within eight hours. Missing or stale close remains unavailable, never reconstructed with today's FX.

## Verification

Main7 Jest suites134 passed; FX29 passed; real PostgreSQL27 passed; scoped test types and runtime lint passed. Final runtime/schema/UTC/format gates and Arabic live language-switch investigation remain. See the durable resume checkpoint in davintrade-local-gold-price/worldgoldmarket-resume-checkpoint.md.

## Continuation

Next: resolve Arabic live dictionary fallback, finish final gates and handoff. Checkpoint: davintrade-local-gold-price/worldgoldmarket-resume-checkpoint.md. Current observed HEAD a89fdd85b8291c8a2de0ab137eba3aa5a7fe34b8; unrelated Claude changes preserved. Shared state publication remains handoff-only.
